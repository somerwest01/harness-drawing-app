// Custom hook for canvas logic

const useCanvasLogic = () => {
    // logic here
};

export default useCanvasLogic;
