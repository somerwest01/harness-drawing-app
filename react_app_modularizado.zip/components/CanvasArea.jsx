// CanvasArea.jsx component

import React from 'react';

const CanvasArea = () => {
    return <div>CanvasArea works!</div>;
};

export default CanvasArea;
