// LineTable.jsx component

import React from 'react';

const LineTable = () => {
    return <div>LineTable works!</div>;
};

export default LineTable;
