// DimensionInput.jsx component

import React from 'react';

const DimensionInput = () => {
    return <div>DimensionInput works!</div>;
};

export default DimensionInput;
