// ObjectEditor.jsx component

import React from 'react';

const ObjectEditor = () => {
    return <div>ObjectEditor works!</div>;
};

export default ObjectEditor;
