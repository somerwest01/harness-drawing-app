// FileButtons.jsx component

import React from 'react';

const FileButtons = () => {
    return <button>FileButtons</button>;
};

export default FileButtons;
